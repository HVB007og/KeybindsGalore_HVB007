package net.hvb007.keybindsgalore;

import net.hvb007.keybindsgalore.mixin.KeyMappingAccessor;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_5250;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Manages the detection and resolution of conflicting keybinds.
 */
public class KeybindManager {
    // Maps a physical key to a list of all KeyBinding objects bound to it.
    public static final Map<class_3675.class_306, List<class_304>> conflictTable = new HashMap<>();
    // Tracks keys that are in "click and hold" mode. This is a placeholder for a future feature.
    public static final HashMap<Integer, class_304> clickHoldKeys = new HashMap<>();
    // Tracks which conflict warnings have been shown to the player in this session.
    public static final HashSet<class_3675.class_306> shownConflictWarnings = new HashSet<>();

    /**
     * Safely gets the translation key (ID) of a keybinding.
     */
    public static String safeGetTranslationKey(class_304 binding) {
        return binding.method_1431();
    }

    /**
     * Safely gets the display name of a keybinding's category.
     */
    public static String safeGetCategory(class_304 binding) {
        return binding.method_1423();
    }

    /**
     * Scans all registered keybindings and populates the conflictTable.
     * This is the core of the conflict detection system.
     */
    public static void findAllConflicts() {
        KeybindsGalore.LOGGER.info("Scanning for conflicting keybinds...");
        class_310 client = class_310.method_1551();
        
        validateAndMigratePriorityKeybinds(client);

        conflictTable.clear();
        shownConflictWarnings.clear(); // Clear previous warnings

        for (class_304 keybinding : client.field_1690.field_1839) { // Use client.options.allKeys for Yarn
            // 1. Filter out keybinds from configured categories.
            if (Configurations.FILTERED_CATEGORY_KEYS.stream().anyMatch(s -> s.equalsIgnoreCase(safeGetCategory(keybinding)))) {
                continue;
            }

            class_3675.class_306 physicalKey = ((KeyMappingAccessor) keybinding).getKey();
            if (physicalKey.method_1444() == GLFW.GLFW_KEY_UNKNOWN) {
                continue; // Ignore unbound keys.
            }

            conflictTable.computeIfAbsent(physicalKey, k -> new ArrayList<>()).add(keybinding);
        }

        // Clean up the table by removing entries with no actual conflicts.
        conflictTable.keySet().removeIf(key -> conflictTable.get(key).size() < 2);
    }

    /**
     * Migrates old priority entries (ActionID) to the new format (ActionID:KeyName).
     */
    private static void validateAndMigratePriorityKeybinds(class_310 client) {
        boolean changed = false;
        List<String> newPriorities = new ArrayList<>();
        HashSet<String> uniqueKeys = new HashSet<>();

        for (String entry : Configurations.PRIORITY_KEYBINDS) {
            if (!entry.contains(":")) {
                // Old format. Try to find the key for this action.
                for (class_304 kb : client.field_1690.field_1839) {
                    if (kb.method_1431().equals(entry)) {
                        String keyName = ((KeyMappingAccessor) kb).getKey().method_1441();
                        String newEntry = entry + ":" + keyName;
                        if (!uniqueKeys.contains(keyName)) {
                            newPriorities.add(newEntry);
                            uniqueKeys.add(keyName);
                            changed = true;
                        }
                        break;
                    }
                }
            } else {
                String keyName = entry.split(":", 2)[1];
                if (!uniqueKeys.contains(keyName)) {
                    newPriorities.add(entry);
                    uniqueKeys.add(keyName);
                } else {
                    // Duplicate priority for the same key. Remove it.
                    changed = true;
                }
            }
        }

        if (changed) {
            Configurations.PRIORITY_KEYBINDS.clear();
            Configurations.PRIORITY_KEYBINDS.addAll(newPriorities);
            KeybindsGalore.configManager.saveConfigFile();
        }
    }

    /**
     * Checks if a key is currently in "click and hold" mode.
     */
    public static boolean isClickHoldKey(class_3675.class_306 key) {
        return clickHoldKeys.containsKey(key.method_1444());
    }

    /**
     * Checks if a physical key has multiple keybindings assigned to it.
     */
    public static boolean hasConflicts(class_3675.class_306 key) {
        return conflictTable.containsKey(key);
    }

    /**
     * Opens the conflict resolution screen (the selection menu).
     */
    public static void openConflictMenu(class_3675.class_306 key) {
        class_437 screen;
        if (Configurations.USE_CIRCULAR_MENU) {
            screen = new KeybindCircularScreen(key);
        } else {
            screen = new KeybindSelectorScreen(key);
        }
        class_310.method_1551().method_1507(screen);
    }

    /**
     * Returns the list of conflicting keybindings for a given physical key.
     */
    public static List<class_304> getConflicts(class_3675.class_306 key) {
        return conflictTable.get(key);
    }

    /**
     * Intercepts the onKeyPressed event to prevent `timesPressed` from incrementing on conflicting keys.
     * This stops the game from thinking a "click" happened when we are just opening the menu.
     */
    public static void handleOnKeyPressed(class_3675.class_306 key, CallbackInfo ci) {
        if (hasConflicts(key) && !isClickHoldKey(key)) {
            // ALWAYS cancel vanilla click for conflicting keys.
            // Vanilla's `click` method blindly increments the clickCount of whichever KeyMapping 
            // happens to be stored in its internal `MAP` for this physical key (ignoring aliases).
            // We manually increment the correct priority key's clickCount in handleKeyPress.
            ci.cancel();
        }
    }

    /**
     * Determines which keybinding, if any, has priority for a given physical key.
     */
    public static class_304 getPriorityKey(class_3675.class_306 key) {
        if (!hasConflicts(key)) return null;

        List<class_304> conflicts = getConflicts(key);
        if (conflicts == null) return null;

        class_304 categoryPriority = null;

        // 1. Check for individually prioritized keybinds (EXCLUSIVE to this physical key)
        for (class_304 kb : conflicts) {
            String priorityPair = safeGetTranslationKey(kb) + ":" + key.method_1441();
            if (Configurations.PRIORITY_KEYBINDS.stream().anyMatch(s -> s.equalsIgnoreCase(priorityPair))) {
                return kb; // Direct match always wins immediately
            }
            
            // Check category fallback while we loop, but don't return immediately
            if (categoryPriority == null) {
                if (Configurations.PRIORITY_CATEGORIES.stream().anyMatch(s -> s.equalsIgnoreCase(safeGetCategory(kb)))) {
                    categoryPriority = kb;
                }
            }
        }

        // 2. If no individual priority, return the category priority if found
        return categoryPriority;
    }

    /**
     * The main entry point for intercepting key presses.
     * This method decides whether to execute a priority action, open the conflict menu, or do nothing.
     */
    public static void handleKeyPress(class_3675.class_306 key, boolean pressed, CallbackInfo ci) {
        if (Configurations.DEBUG) {
            KeybindsGalore.LOGGER.info("[KBG DEBUG] Key Input: {} | Pressed: {}", key.method_1441(), pressed);
        }

        boolean wasSelectorScreenOpen = class_310.method_1551().field_1755 instanceof KeybindSelectorScreen || class_310.method_1551().field_1755 instanceof KeybindCircularScreen;

        if (hasConflicts(key)) {
            if (Configurations.DEBUG) {
                KeybindsGalore.LOGGER.info("[KBG DEBUG] Conflict detected for key: {}", key.method_1441());
            }

            if (!isClickHoldKey(key)) {
                class_304 priorityKey = getPriorityKey(key);

                if (priorityKey != null) {
                    if (Configurations.DEBUG) {
                        KeybindsGalore.LOGGER.info("[KBG DEBUG] Executing priority action: {} | State: {}", priorityKey.method_1431(), pressed ? "PRESSED" : "RELEASED");
                    }
                    
                    // Manually force the pressed state for hold actions (like moving)
                    ((KeyMappingAccessor) priorityKey).setIsDown(pressed);

                    if (pressed) {
                        // Manually increment the click count for click-based actions (like hotbar slots)
                        int currentClicks = ((KeyMappingAccessor) priorityKey).getClickCount();
                        ((KeyMappingAccessor) priorityKey).setClickCount(currentClicks + 1);
                        
                        // Set it as the pulse target so the mixin allows it through vanilla polling
                        KeybindsGalore.activePulseTarget = priorityKey;
                    } else {
                        // If it's released, clear the target
                        if (KeybindsGalore.activePulseTarget == priorityKey) {
                            KeybindsGalore.activePulseTarget = null;
                        }
                    }

                    // Cancel the original event so we don't accidentally trigger the non-priority conflicting keys
                    ci.cancel();

                    if (pressed && !shownConflictWarnings.contains(key)) {
                        if (Configurations.SHOW_CONFLICT_WARNINGS) {
                            class_310 client = class_310.method_1551();
                            if (client.field_1724 != null) {
                                class_5250 warningHeader = class_2561.method_43470("KeybindsGalore Warning: Key '")
                                    .method_10852(class_2561.method_43470(key.method_27445().getString()).method_27692(class_124.field_1065))
                                    .method_10852(class_2561.method_43470("' has conflicts. Prioritizing '"))
                                    .method_10852(class_2561.method_43471(priorityKey.method_1431()).method_27692(class_124.field_1075))
                                    .method_10852(class_2561.method_43470("'."))
                                    .method_27692(class_124.field_1061);
                                client.field_1724.method_7353(warningHeader, false);

                                // ADDED: Display other conflicting keybinds
                                class_5250 otherKeys = class_2561.method_43470("");
                                boolean first = true;
                                for (class_304 otherKb : getConflicts(key)) {
                                    if (otherKb == priorityKey) continue;
                                    if (!first) {
                                        otherKeys.method_10852(class_2561.method_43470(", ").method_27692(class_124.field_1080));
                                    }
                                    otherKeys.method_10852(class_2561.method_43471(otherKb.method_1431()).method_27692(class_124.field_1054));
                                    first = false;
                                }

                                if (!otherKeys.getString().isEmpty()) {
                                     client.field_1724.method_7353(
                                        class_2561.method_43470("Other conflicting keybinds: ").method_27692(class_124.field_1080)
                                        .method_10852(otherKeys)
                                        .method_10852(class_2561.method_43470(". Please rebind them in your controls! If you do not want to see these error Messages in Chat, Set SHOW_CONFLICT_WARNINGS=false in keybindsgalore.properties file in your config folder.").method_27692(class_124.field_1080)),
                                        false
                                    );
                                }
                            }
                        }
                        shownConflictWarnings.add(key);
                    }
                    return; // Return immediately, letting vanilla take over
                } else {
                    // No priority key found.
                    if (pressed) {
                        if (Configurations.DEBUG) {
                            KeybindsGalore.LOGGER.info("[KBG DEBUG] No priority found, opening conflict menu for key: {}", key.method_1441());
                        }
                        // Open the conflict resolution menu.
                        ci.cancel();
                        openConflictMenu(key);
                    } else {
                        // Release logic for menu
                        if (wasSelectorScreenOpen) {
                            class_437 currentScreen = class_310.method_1551().field_1755;
                            if (currentScreen instanceof KeybindSelectorScreen) {
                                ((KeybindSelectorScreen) currentScreen).onKeyRelease();
                            } else if (currentScreen instanceof KeybindCircularScreen) {
                                ((KeybindCircularScreen) currentScreen).onKeyRelease();
                            }
                        }
                        
                        // Also ensure all conflicting keys are released
                        List<class_304> conflicts = getConflicts(key);
                        if (conflicts != null) {
                            for (class_304 kb : conflicts) {
                                ((KeyMappingAccessor) kb).setIsDown(false);
                            }
                        }
                        ci.cancel();
                    }
                }
                return;
            }
        } else if (Configurations.DEBUG) {
            KeybindsGalore.LOGGER.info("[KBG DEBUG] No conflicts for key: {}", key.method_1441());
        }

        // --- RELEASE LOGIC FOR PULSE ---
        if (!pressed) {
            if (KeybindsGalore.pulseTimer > 0 && KeybindsGalore.activePulseTarget != null) {
                class_3675.class_306 targetKey = ((KeyMappingAccessor) KeybindsGalore.activePulseTarget).getKey();
                if (key.equals(targetKey)) {
                    ((KeyMappingAccessor) KeybindsGalore.activePulseTarget).setIsDown(true);
                    ci.cancel();
                }
            }
        }
    }

    /**
     * Adds a prioritized action for a specific key, replacing any existing priority for that same key.
     */
    public static void prioritizeAction(class_304 selected, class_3675.class_306 key) {
        String newPair = selected.method_1431() + ":" + key.method_1441();
        
        // Exclusivity Check: Remove any existing priority entry that uses this same physical key
        Configurations.PRIORITY_KEYBINDS.removeIf(entry -> {
            if (entry.contains(":")) {
                String existingKeyName = entry.split(":", 2)[1];
                return existingKeyName.equalsIgnoreCase(key.method_1441());
            }
            return false;
        });

        Configurations.PRIORITY_KEYBINDS.add(newPair);
        KeybindsGalore.configManager.saveConfigFile();
        findAllConflicts();
        
        if (class_310.method_1551().field_1724 != null) {
            class_310.method_1551().field_1724.method_7353(
                class_2561.method_43469("text.keybindsgalore.action_prioritized", 
                class_2561.method_43471(selected.method_1431()), 
                class_2561.method_43471(key.method_1441())), false
            );
        }
    }

    /**
     * Removes the prioritized action for a specific key.
     */
    public static void removePriority(class_3675.class_306 key) {
        boolean removed = Configurations.PRIORITY_KEYBINDS.removeIf(entry -> {
            if (entry.contains(":")) {
                String existingKeyName = entry.split(":", 2)[1];
                return existingKeyName.equalsIgnoreCase(key.method_1441());
            }
            return false;
        });

        if (removed) {
            KeybindsGalore.configManager.saveConfigFile();
            findAllConflicts();
            
            if (class_310.method_1551().field_1724 != null) {
                class_310.method_1551().field_1724.method_7353(
                    class_2561.method_43469("text.keybindsgalore.priority_removed", 
                    class_2561.method_43471(key.method_1441())), false
                );
            }
        }
    }
}
