/*
 * This file is heavily inspired by the PSI mod by Vazkii.
 */
package net.hvb007.keybindsgalore;

import net.hvb007.keybindsgalore.mixin.KeyMappingAccessor;
import net.hvb007.keybindsgalore.mixin.MinecraftAccessor;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_333;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static net.hvb007.keybindsgalore.KeybindsGalore.customDataManager;

/**
 * The conflict resolution screen, which displays a list of keybindings
 * that share the same physical key.
 */
public class KeybindSelectorScreen extends class_437 {
    private static final int BOX_HORIZONTAL_PADDING = 3;
    private static final int BOX_VERTICAL_PADDING = 3;
    private static final int BOX_SPACING = 3;
    private static final int SCREEN_MARGIN = 50;

    private final class_3675.class_306 conflictedKey;
    private final List<class_304> conflicts = new ArrayList<>();
    private final List<BoxDimensions> cachedBoxes = new ArrayList<>();

    private int widthCenter, heightCenter;
    private boolean firstFrame = true;
    private int selectedIndex = -1;

    private List<class_304> topList, bottomList;
    private int halfCount, topStartY, bottomStartY;

    public KeybindSelectorScreen(class_3675.class_306 key) {
        super(class_333.field_18967);
        this.conflictedKey = key;
        this.conflicts.addAll(KeybindManager.getConflicts(key));
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        method_25420(ctx, mouseX, mouseY, delta);
        if (firstFrame) {
            widthCenter = field_22789 / 2;
            heightCenter = field_22790 / 2;
            calculateLayout();
            firstFrame = false;
        }

        updateSelection(mouseX, mouseY);
        renderMenu(ctx);
        renderLabels(ctx);
    }

    /**
     * Called by the KeybindManager when the physical key is released.
     * This is the trigger to finalize the selection.
     */
    public void onKeyRelease() {
        handleSelectionFinish();
    }

    /**
     * Finalizes the keybind selection, activates the chosen keybind,
     * and closes the menu.
     */
    private void handleSelectionFinish() {
        if (selectedIndex != -1) {
            class_304 kb = conflicts.get(selectedIndex);

            // Set the chosen key as the "pulse target" to keep it pressed.
            KeybindsGalore.activePulseTarget = kb;
            KeybindsGalore.pulseTimer = 5;

            // Manually press the keybind to ensure it activates.
            ((KeyMappingAccessor) kb).setIsDown(true);
            ((KeyMappingAccessor) kb).setClickCount(1);

            // Apply a workaround for the attack key if needed.
            if (kb.method_1435(class_310.method_1551().field_1690.field_1886) && Configurations.ENABLE_ATTACK_WORKAROUND) {
                ((MinecraftAccessor) class_310.method_1551()).setMissTime(0);
            }
        }
        // If no key was selected, we do nothing and let the KeybindManager handle the reset.

        closeMenu();
    }

    /**
     * Calculates the dimensions and positions of all the list items.
     */
    private void calculateLayout() {
        cachedBoxes.clear();
        halfCount = conflicts.size() / 2;
        topList = conflicts.subList(0, halfCount);
        bottomList = conflicts.subList(halfCount, conflicts.size());

        int boxHeight = field_22793.field_2000 + 2 * BOX_VERTICAL_PADDING;
        int maxWidth = 0;
        for (class_304 kb : conflicts) {
            String name = formatName(kb);
            int textW = field_22793.method_1727(name);
            int totalW = textW + 2 * BOX_HORIZONTAL_PADDING;
            maxWidth = Math.max(maxWidth, totalW);
            BoxDimensions dim = new BoxDimensions();
            dim.height = boxHeight;
            cachedBoxes.add(dim);
        }
        maxWidth = Math.min(maxWidth, field_22789 - 2 * SCREEN_MARGIN);
        for (BoxDimensions d : cachedBoxes) d.finalWidth = maxWidth;

        int topHeight = topList.size() * boxHeight + (topList.size() - 1) * BOX_SPACING;
        topStartY = heightCenter - BOX_SPACING / 2 - topHeight;
        bottomStartY = heightCenter + BOX_SPACING / 2;
    }

    /**
     * Renders the background boxes for each keybinding in the list.
     */
    private void renderMenu(class_332 ctx) {
        for (int i = 0; i < topList.size(); i++) {
            BoxDimensions dim = cachedBoxes.get(i);
            int x = widthCenter - (dim.finalWidth / 2);
            int y = topStartY + i * (dim.height + BOX_SPACING);
            drawBox(ctx, x, y, dim.finalWidth, dim.height, i);
        }
        for (int i = 0; i < bottomList.size(); i++) {
            BoxDimensions dim = cachedBoxes.get(i + halfCount);
            int x = widthCenter - (dim.finalWidth / 2);
            int y = bottomStartY + i * (dim.height + BOX_SPACING);
            drawBox(ctx, x, y, dim.finalWidth, dim.height, i + halfCount);
        }
    }

    /**
     * Renders the text labels for each keybinding.
     */
    private void renderLabels(class_332 ctx) {
        for (int i = 0; i < conflicts.size(); i++) {
            BoxDimensions dim = cachedBoxes.get(i);
            int baseY = (i < halfCount)
                    ? topStartY + i * (dim.height + BOX_SPACING)
                    : bottomStartY + (i - halfCount) * (dim.height + BOX_SPACING);
            int x = widthCenter - (dim.finalWidth / 2);
            int y = baseY;
            if (selectedIndex == i) {
                x -= 2;
                y -= 1;
            }
            String name = formatName(conflicts.get(i));
            if (selectedIndex == i) {
                name = class_124.field_1073 + name;
            }
            int tw = field_22793.method_1727(name);
            ctx.method_51433(field_22793, name,
                    x + (dim.finalWidth - tw) / 2,
                    y + (dim.height - field_22793.field_2000) / 2,
                    0xFFFFFFFF, true);
        }
    }

    private void drawBox(class_332 ctx, int x, int y, int w, int h, int idx) {
        int bg = Configurations.PIE_MENU_COLOR;
        if (customDataManager.hasCustomData) {
            try {
                String key = KeybindManager.safeGetTranslationKey(conflicts.get(idx));
                bg = customDataManager.customData.get(key).sectorColor;
            } catch (Exception ignored) {
            }
        }
        if (selectedIndex == idx) {
            bg = Configurations.PIE_MENU_HIGHLIGHT_COLOR;
            x -= 2;
            y -= 1;
            w += 4;
            h += 2;
        }
        int alpha = (Configurations.PIE_MENU_ALPHA << 24) | (bg & 0x00FFFFFF);
        ctx.method_25294(x, y, x + w, y + h, alpha);
    }

    /**
     * Updates the currently selected index based on the mouse position.
     */
    private void updateSelection(int mx, int my) {
        selectedIndex = -1;
        for (int i = 0; i < conflicts.size(); i++) {
            BoxDimensions dim = cachedBoxes.get(i);
            int y0 = (i < halfCount)
                    ? topStartY + i * (dim.height + BOX_SPACING)
                    : bottomStartY + (i - halfCount) * (dim.height + BOX_SPACING);
            int x0 = widthCenter - (dim.finalWidth / 2);
            if (mx >= x0 && mx <= x0 + dim.finalWidth && my >= y0 && my <= y0 + dim.height) {
                selectedIndex = i;
                break;
            }
        }
    }

    /**
     * Formats the name of a keybinding for display, including its category.
     */
    private String formatName(class_304 kb) {
        String id = KeybindManager.safeGetTranslationKey(kb);
        String cat = KeybindManager.safeGetCategory(kb);
        String name = class_2561.method_43471(cat).getString() + ": " + class_2561.method_43471(id).getString();
        if (customDataManager.hasCustomData) {
            try {
                if (customDataManager.customData.get(id).hideCategory)
                    name = class_2561.method_43471(id).getString();
                name = Objects.requireNonNull(customDataManager.customData.get(id).displayName);
            } catch (Exception ignored) {
            }
        }
        return name;
    }

    private void closeMenu() {
        class_310.method_1551().method_1507(null);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25420(class_332 ctx, int mx, int my, float d) {
        if (Configurations.DARKENED_BACKGROUND) {
            ctx.method_25294(0, 0, field_22789, field_22790, 0x60000000);
        }
    }

    private static class BoxDimensions {
        int finalWidth, height;
    }
}
