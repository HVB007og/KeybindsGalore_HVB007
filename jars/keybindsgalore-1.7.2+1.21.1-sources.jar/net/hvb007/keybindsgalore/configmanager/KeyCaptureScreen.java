package net.hvb007.keybindsgalore.configmanager;

import net.hvb007.keybindsgalore.KeybindManager;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class KeyCaptureScreen extends class_437 {
    private final class_437 parent;
    private final BiConsumer<class_3675.class_306, List<class_304>> callback;

    public KeyCaptureScreen(class_437 parent, BiConsumer<class_3675.class_306, List<class_304>> callback) {
        super(class_2561.method_43471("title.keybindsgalore.capture"));
        this.parent = parent;
        this.callback = callback;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, class_2561.method_43471("text.keybindsgalore.press_any_key"), this.field_22789 / 2, this.field_22790 / 2 - 20, 0xFFFFFFFF);
        context.method_27534(this.field_22793, class_2561.method_43471("text.keybindsgalore.capture_instruction"), this.field_22789 / 2, this.field_22790 / 2, 0xAAAAAA);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) { // ESC
            class_310.method_1551().method_1507(parent);
            return true;
        }

        class_3675.class_306 key = class_3675.class_307.field_1668.method_1447(keyCode);
        List<class_304> conflicts = new ArrayList<>();
        
        for (class_304 kb : class_310.method_1551().field_1690.field_1839) {
            if (((net.hvb007.keybindsgalore.mixin.KeyMappingAccessor) kb).getKey().equals(key)) {
                conflicts.add(kb);
            }
        }

        if (!conflicts.isEmpty()) {
            callback.accept(key, conflicts);
        } else {
            // No keybinds on this key. Just go back.
            class_310.method_1551().method_1507(parent);
        }
        
        return true;
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        class_3675.class_306 key = class_3675.class_307.field_1672.method_1447(button);
        List<class_304> conflicts = new ArrayList<>();
        
        for (class_304 kb : class_310.method_1551().field_1690.field_1839) {
            if (((net.hvb007.keybindsgalore.mixin.KeyMappingAccessor) kb).getKey().equals(key)) {
                conflicts.add(kb);
            }
        }

        if (!conflicts.isEmpty()) {
            callback.accept(key, conflicts);
        } else {
            class_310.method_1551().method_1507(parent);
        }
        return true;
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(parent);
    }
}
