package net.hvb007.keybindsgalore.configmanager;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ActionSelectionScreen extends class_437 {
    private final class_437 parent;
    private final List<class_304> options;
    private final Consumer<class_304> callback;
    private final Runnable removeCallback;

    public ActionSelectionScreen(class_437 parent, List<class_304> options, Consumer<class_304> callback, Runnable removeCallback) {
        super(class_2561.method_43471("title.keybindsgalore.select_action"));
        this.parent = parent;
        this.options = options;
        this.callback = callback;
        this.removeCallback = removeCallback;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        int y = this.field_22790 / 2 - (options.size() * 25) / 2;
        
        // Add a "Remove Priority" button at the top if there are options
        this.method_37063(class_4185.method_46430(class_2561.method_43471("button.keybindsgalore.remove_priority"), button -> {
            removeCallback.run();
            class_310.method_1551().method_1507(parent);
        }).method_46434(this.field_22789 / 2 - 100, y - 30, 200, 20).method_46431());

        for (class_304 kb : options) {
            this.method_37063(class_4185.method_46430(class_2561.method_43471(kb.method_1423()).method_27693(": ").method_10852(class_2561.method_43471(kb.method_1431())), button -> {
                callback.accept(kb);
                class_310.method_1551().method_1507(parent);
            }).method_46434(this.field_22789 / 2 - 100, y, 200, 20).method_46431());
            y += 25;
        }
        
        this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.cancel"), button -> {
            class_310.method_1551().method_1507(parent);
        }).method_46434(this.field_22789 / 2 - 100, this.field_22790 - 30, 200, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFFFF);
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(parent);
    }
}
