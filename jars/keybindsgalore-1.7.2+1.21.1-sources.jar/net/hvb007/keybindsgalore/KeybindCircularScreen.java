package net.hvb007.keybindsgalore;

import net.hvb007.keybindsgalore.mixin.KeyMappingAccessor;
import net.hvb007.keybindsgalore.mixin.MinecraftAccessor;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_333;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static net.hvb007.keybindsgalore.KeybindsGalore.customDataManager;

public class KeybindCircularScreen extends class_437 {

    private final class_3675.class_306 conflictedKey;
    private final List<class_304> conflicts = new ArrayList<>();
    private int selectedSectorIndex = -1;

    private int centreX = 0, centreY = 0;
    private float maxRadius = 0;
    private float cancelZoneRadius = 0;

    public KeybindCircularScreen(class_3675.class_306 key) {
        super(class_333.field_18967);
        this.conflictedKey = key;
        this.conflicts.addAll(KeybindManager.getConflicts(key));
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        this.centreX = this.field_22789 / 2;
        this.centreY = this.field_22790 / 2;
        this.maxRadius = Math.min(this.field_22789, this.field_22790) / 2.0f * 0.8f;
        this.cancelZoneRadius = maxRadius * 0.2f;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        if (Configurations.DARKENED_BACKGROUND) {
            this.method_25420(context, mouseX, mouseY, delta);
        }

        double mouseAngle = mouseAngle(this.centreX, this.centreY, mouseX, mouseY);
        float mouseDistanceFromCentre = class_3532.method_15355((float) ((mouseX - this.centreX) * (mouseX - this.centreX) + (mouseY - this.centreY) * (mouseY - this.centreY)));

        int numberOfSectors = this.conflicts.size();
        if (numberOfSectors == 0) return;

        float sectorAngle = (float) (class_3532.field_29846 / numberOfSectors);

        this.selectedSectorIndex = (int) (mouseAngle / sectorAngle);
        if (this.selectedSectorIndex >= numberOfSectors) this.selectedSectorIndex = numberOfSectors - 1;
        if (this.selectedSectorIndex < 0) this.selectedSectorIndex = 0;

        if (mouseDistanceFromCentre <= this.cancelZoneRadius) {
            this.selectedSectorIndex = -1;
        }

        final int colorEven = Configurations.PIE_MENU_SECTOR_COLOR_EVEN;
        final int colorOdd = Configurations.PIE_MENU_SECTOR_COLOR_ODD;
        final int colorSelected = Configurations.PIE_MENU_SECTOR_COLOR_SELECTED;
        final int colorLastOddFix = Configurations.PIE_MENU_SECTOR_COLOR_LAST_ODD;

        for (int i = 0; i < numberOfSectors; i++) {
            float startAngle = i * sectorAngle;
            float endAngle = (i + 1) * sectorAngle;

            int color;
            float currentRadius = this.maxRadius;

            if (i == this.selectedSectorIndex) {
                color = colorSelected;
            } else {
                if (numberOfSectors % 2 != 0 && i == numberOfSectors - 1) {
                    color = colorLastOddFix;
                } else {
                    color = (i % 2 == 0) ? colorEven : colorOdd;
                }
            }

            TriangleStripRenderer.drawSector(context, this.centreX, this.centreY, startAngle, endAngle, this.cancelZoneRadius, currentRadius, color);
        }

        int cancelZoneColor = Configurations.PIE_MENU_CANCEL_ZONE_COLOR;
        if (mouseDistanceFromCentre <= this.cancelZoneRadius) {
            cancelZoneColor = Configurations.PIE_MENU_CANCEL_ZONE_HOVER_COLOR;
        }
        
        for (int i = 0; i < numberOfSectors; i++) {
            float start = i * sectorAngle;
            float end = (i + 1) * sectorAngle;
            TriangleStripRenderer.drawSector(context, this.centreX, this.centreY, start, end, 0, this.cancelZoneRadius, cancelZoneColor);
        }

        renderLabelTexts(context, numberOfSectors);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void renderLabelTexts(class_332 context, int numberOfSectors) {
        if (numberOfSectors == 0) return;

        class_327 textRenderer = class_310.method_1551().field_1772;

        for (int sectorIndex = 0; sectorIndex < numberOfSectors; sectorIndex++) {
            float sectorAngle = (float) (class_3532.field_29846 / numberOfSectors);
            float radius = this.maxRadius;
            
            float textRadius = radius * 1.1f;
            float angle = (sectorIndex + 0.5f) * sectorAngle;

            float xPos = this.centreX + class_3532.method_15362(angle) * textRadius;
            float yPos = this.centreY + class_3532.method_15374(angle) * textRadius;

            class_304 action = this.conflicts.get(sectorIndex);
            String actionName = formatName(action).getString();

            int textWidth = textRenderer.method_1727(actionName);
            int textHeight = textRenderer.field_2000;

            if (xPos > this.centreX) {
                xPos -= Configurations.LABEL_TEXT_INSET;
                if (this.field_22789 - xPos < textWidth)
                    xPos -= textWidth - this.field_22789 + xPos;
            } else {
                xPos -= textWidth - Configurations.LABEL_TEXT_INSET;
                if (xPos < 0) xPos = Configurations.LABEL_TEXT_INSET;
            }
            yPos -= Configurations.LABEL_TEXT_INSET;

            if (this.selectedSectorIndex == sectorIndex) {
                actionName = class_124.field_1073 + actionName;
                context.method_25294((int)xPos - 2, (int)yPos - 2, (int)xPos + textWidth + 2, (int)yPos + textHeight + 2, 0x80E0E0E0);
            }

            context.method_51433(textRenderer, actionName, (int) xPos, (int) yPos, 0xFFFFFFFF, true);
        }
    }

    private static double mouseAngle(int x, int y, int mx, int my) {
        return (class_3532.method_15349(my - y, mx - x) + Math.PI * 2) % (Math.PI * 2);
    }

    public void onKeyRelease() {
        closePieMenu();
    }

    private void closePieMenu() {
        class_310 client = class_310.method_1551();
        client.method_1507(null);

        if (this.selectedSectorIndex != -1 && this.selectedSectorIndex < this.conflicts.size()) {
            class_304 selectedKeyBinding = this.conflicts.get(this.selectedSectorIndex);
            KeybindsGalore.activePulseTarget = selectedKeyBinding;
            KeybindsGalore.pulseTimer = 5;
            ((KeyMappingAccessor) selectedKeyBinding).setIsDown(true);
            ((KeyMappingAccessor) selectedKeyBinding).setClickCount(1);

            if (selectedKeyBinding.method_1435(client.field_1690.field_1886) && Configurations.ENABLE_ATTACK_WORKAROUND) {
                ((MinecraftAccessor) client).setMissTime(0);
            }
        }
    }

    private class_2561 formatName(class_304 kb) {
        String id = KeybindManager.safeGetTranslationKey(kb);
        String cat = KeybindManager.safeGetCategory(kb);
        String nameStr = class_2561.method_43471(cat).getString() + ": " + class_2561.method_43471(id).getString();
        if (customDataManager.hasCustomData) {
            try {
                if (customDataManager.customData.get(id).hideCategory)
                    nameStr = class_2561.method_43471(id).getString();
                nameStr = Objects.requireNonNull(customDataManager.customData.get(id).displayName);
            } catch (Exception ignored) {
            }
        }
        return class_2561.method_43470(nameStr);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        if (Configurations.DARKENED_BACKGROUND) {
            context.method_25294(0, 0, this.field_22789, this.field_22790, 0x60000000);
        }
    }
}
