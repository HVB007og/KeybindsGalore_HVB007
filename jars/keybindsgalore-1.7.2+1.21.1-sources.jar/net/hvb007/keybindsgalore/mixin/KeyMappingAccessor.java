package net.hvb007.keybindsgalore.mixin;

import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Provides direct access to private fields and methods of the KeyBinding class.
 */
@Mixin(class_304.class)
public interface KeyMappingAccessor {
    /**
     * Accessor for the 'timesPressed' field.
     */
    @Accessor
    void setClickCount(int timesPressed);

    @Accessor
    int getClickCount();

    /**
     * Accessor for the 'pressed' field.
     */
    @Accessor("isDown")
    void setIsDown(boolean pressed);

    /**
     * Accessor for the 'boundKey' field.
     */
    @Accessor
    class_3675.class_306 getKey();

    /**
     * Invoker for the 'reset' method.
     */
    @Invoker("release")
    void invokeRelease();
}
