package net.hvb007.keybindsgalore.mixin;

import net.hvb007.keybindsgalore.KeybindManager;
import net.minecraft.class_2561;
import net.minecraft.class_315;
import net.minecraft.class_437;
import net.minecraft.class_4667;
import net.minecraft.class_6599;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Mixin for the vanilla Keybinds screen.
 */
@Mixin(class_6599.class)
public abstract class KeyBindsScreenMixin extends class_4667 {
    public KeyBindsScreenMixin(class_437 parent, class_315 gameOptions, class_2561 title) {
        super(parent, gameOptions, title);
    }

    /**
     * Re-scans for conflicting keybinds every time the user closes the controls menu.
     * This ensures our conflict list is always up-to-date.
     */
    @Override
    public void method_25419() {
        super.method_25419();
        KeybindManager.findAllConflicts();
    }
}
