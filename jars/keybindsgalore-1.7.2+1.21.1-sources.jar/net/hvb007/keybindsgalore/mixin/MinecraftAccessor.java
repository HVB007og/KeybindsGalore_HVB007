package net.hvb007.keybindsgalore.mixin;

import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_310.class)
public interface MinecraftAccessor
{
    // Allows us to manually reset the left-click delay (cooldown)
    // Useful if the radial menu triggers an attack action and we want it to happen instantly
    @Accessor void setMissTime(int attackCooldown);
}